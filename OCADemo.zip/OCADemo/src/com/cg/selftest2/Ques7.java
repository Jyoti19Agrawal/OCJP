package com.cg.selftest2;

public class Ques7 {
	Ques7() {
		main("hi");
	}

	public static void main(String[] args) {
		System.out.print("2 ");
	}

	public static void main(String args) {
		System.out.print("3 " + args);
	}
}

 
