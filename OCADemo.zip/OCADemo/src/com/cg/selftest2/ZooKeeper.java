package com.cg.selftest2;

class Mammal {
	String name = "furry ";

	String makeNoise() {
		return "generic noise";
	}
}

class Zebra extends Mammal {
	String name = "stripes ";

	String makeNoise() {
		return "bray";
	}
}

public class ZooKeeper {
	public static void main(String[] args) {
		short b= (short) 212337;
		System.out.println(b);
		float gyt = 123456878978L;
		System.out.println(gyt);
		 byte b4=0B1111111;
		 System.out.println(b4);
		byte b1= (byte) 128;
		byte b2= (byte) 129;
		byte b3= (byte) -129;
		int a = 2_12_3;
		int i1=  015237;
		System.out.println(i1);
		int x = 0X0001;
		int y = 0x7fffffff;
		long z =  0xDeadCafeL;
		System.out.println(x);
		System.out.println(y);
		System.out.println(z);
		
		long jo = 110599L;
		long so = 0xFfL;
		System.out.println(jo);
		System.out.println(so);
		int r= 0b1010;
		System.out.println(r);
		int d = 1130187474;
		double d1= 985547874549124567.325d;//optional
		System.out.println(d1);
		
		
		char a1 = '\u007A';
		char b11 = '@';
		System.out.println(a1);
		System.out.println(b11);
		
	
		short i =(short) 5462215152151987f;
		System.out.println(i);
		
		System.out.println(b1);
		System.out.println(b2);
		System.out.println(b3);
		
		
		char c = 0x892; // hexadecimal literal
		char h = 97; // int literal
		char p = (char)70000; // The cast is required; 70000 is
		// out of char range
		char j = (char) -98;
		System.out.println(c);
		System.out.println(h);
		System.out.println(p);
		System.out.println(j);
		
		char quote = '\r'; // A double quote
		char new1 = '\n'; // A newline
		char tab = '\t'; // A tab
		System.out.println(quote);
		
		
		new ZooKeeper().go();
	}

	void go() {
		Mammal m = new Zebra();
		System.out.println(m.name + m.makeNoise());
	}
}


