package com.cg.selftest2;

class Dog {
	public void bark() {
		System.out.print("woof ");
	}
}

class Hound extends Dog {
	public void sniff() {
		System.out.print("sniff ");
	}

	public void bark() {
		System.out.print("howl ");
	}
}

public class Ques8 {
	public static void main(String[] args) {
		new Ques8().go();
	}

	 void go() {
		new Hound().bark();
		 Hound h =new Hound();
		 Dog h1=(Dog) new Hound();
		 h1.bark();
		 ((Hound)h1).sniff();
		 
		 
		//((Dog) new Hound()).sniff();
	}
}

