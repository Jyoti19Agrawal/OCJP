package com.cg.selftest2;

abstract interface Frobnicate {
	public void twiddle(String s);
}

public class Ques1 implements Frobnicate{

	public static void main(String[] args) {

	}

	@Override
	public void twiddle(String s) {
		// TODO Auto-generated method stub
		
	}

}

 