package com.cg.chapter2;

/*class UseAnimals {
 public void doStuff(Animal a) {
 System.out.println("In the Animal version");
 }

 public void doStuff(Horse h) {
 System.out.println("In the Horse version");
 }


 }

 public class OverLoadUsingObjectReference {

 public static void main(String[] args) {
 UseAnimals ua = new UseAnimals();
 Animal animalObj = new Animal();
 Animal animalRefToHorse = new Horse();
 Horse horseObj = new Horse();
 ua.doStuff(animalObj);
 ua.doStuff(horseObj);	
 ua.doStuff(animalRefToHorse);
 }
 }






 * Main() can be overloaded
 * class OverLoadUsingObjectReference {

 public static void main(String[] args) {
 main(1);
 }

 static void main(int i) {
 System.out.println("overloaded main");
 }
 }*/

class Dhruvi {
	Dhruvi doStuff(char c) {
		return new Dhruvi();
	}
}

class Mangtani extends Dhruvi {
	Mangtani doStuff(char c) { // legal override in Java 1.5
		return new Mangtani();
	}

	String[] go() {
		return new String[] { "Fred", "Barney", "Wilma" };
	}
	
	//primitive  int can return char also
	public int foo()
	{
		/*char c = 'c';
		return c; // char is compatible with int
*/		
		/*short s = 1;
		return s;*/
		float f = 32.5f;
	
		return (int) f;
		
		
		
	}
}

public class OverLoadUsingObjectReference {
	public static void main(String[] args) {
		Mangtani b = new Mangtani();
		System.out.println(b.foo());
		String[] v = b.go();
		for(String s : v)
		{
			System.out.println(s);	
		}
		
	}
}
