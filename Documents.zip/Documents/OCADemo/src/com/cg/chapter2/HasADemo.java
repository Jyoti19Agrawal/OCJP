package com.cg.chapter2;

class LeadRope{ 
	public void rope()
	{
		System.out.println("Rope of halter");
	}
}

class Halter {
	public void tie(LeadRope aRope) {
	// Do the actual tie work here
		 aRope.rope();
}	
}
public class HasADemo {
	
	//public class Horse extends Animal {
		private Halter myHalter = new Halter();
		public void tie(LeadRope rope) {
		myHalter.tie(rope); // Delegate tie behavior to the
		// Halter object
		}
		public static void main(String[] args) {
			Halter myHalter = new Halter();
			LeadRope lr=new LeadRope();
			myHalter.tie(lr);
		}
	 
}
